class EImages{
  static String lightAppLogo='assets/images/launcher_icon.png';
  static String darkAppLogo='assets/images/darkAZlogo.png';
  static String ipAppLogo = 'assets/images/ip.png';
  static String lightLoadingAppLogo = 'assets/gif/lightLoadingGifAZ.gif';
  static String darkLoadingAppLogo = 'assets/gif/darkLoadingGifAZ.gif';
  static String gearLoadingLogo = 'assets/gif/gearLoading.gif';
}